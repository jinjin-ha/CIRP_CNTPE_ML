%% Christoph Hartmann
% Technical University of Munich, Chair of Metal Forming and Casting
% Walther-Meissner-Starasse 4, 85748 Garching near Munich, Germany
% e-mail: christoph.hartmann@tum.de, phone: +49 89 289 13769
%
% IDDRG 2024 Presentation (only): Classification of material and process properties from punch force measurements during shear cutting using singular value decomposition and unsupervised learning
%
% Example code for manual engineered evaluation domain
%
% Tested in MATLAB R2022a

%%
close all; clc; clear;

%% data 
% X: shear cutting punch-force
% z: punch-travel
%
% Ground truth labels
% Configuration: 1,2,3,4,5,6,7,8,9,10,11 (numClustersConf)
% Material: 1:M270-35A, 2:M350-65A (numClustersMat)
% Clearance: 1:0.007mm, 2:0.019mm, 3:0.035mm, 4:0.05mm, 5:0,07mm (numClustersCle)
% Cutting edge condition: 1:sharp, 2:moderate wear, 3:excessive wear (numClustersEdg)

load('data.mat');

%% Data normalization

X = (X-min(X(:)))./(max(X(:))-min(X(:)));
z = (z-min(z))./(max(z)-min(z));

%% Features

[Fmax,Pmax]=max(X,[],1); % Force maximum and associated punch penetration (normalized)
Fint=(trapz(X,1)-min(trapz(X,1)))./(max(trapz(X,1))-min(trapz(X,1))); % Integrated force over punch penetration (equivalent to work) (normalized)

Veng = [Fmax;Pmax;Fint]';

%% k-means - clustering

%Label: Configurations
numClusters = 11;
labelKmeansConf = kmeans(Veng,numClusters,'Distance','sqeuclidean');
labelKmeansConf = labelKmeansConf';

%Label: Material
numClusters = 2;
labelKmeansMat = kmeans(Veng,numClusters,'Distance','sqeuclidean');
labelKmeansMat = labelKmeansMat';

%Label: Cutting Clearance
numClusters = 5;
labelKmeansCle = kmeans(Veng,numClusters,'Distance','sqeuclidean');
labelKmeansCle = labelKmeansCle';

%Label: Cutting Edge Condition
numClusters = 3;
labelKmeansEdg = kmeans(Veng,numClusters,'Distance','sqeuclidean');
labelKmeansEdg = labelKmeansEdg';

%% hierarchical clustering

Zlink = linkage(Veng,'average','euclidean');
%Label: Configurations
numClusters = 11;
labelHierConf = cluster(Zlink,'maxclust',numClusters);
labelHierConf = labelHierConf';

%Label: Materials
numClusters = 2;
labelHierMat = cluster(Zlink,'maxclust',numClusters);
labelHierMat = labelHierMat';

%Label: Cutting clearance
numClusters = 5;
labelHierCle = cluster(Zlink,'maxclust',numClusters);
labelHierCle = labelHierCle';

%Label: Cutting edge condition
numClusters = 3;
labelHierEdg = cluster(Zlink,'maxclust',numClusters);
labelHierEdg = labelHierEdg';



