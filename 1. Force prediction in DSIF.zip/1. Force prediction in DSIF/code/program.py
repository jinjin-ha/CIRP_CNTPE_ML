# This code corresponds to the research study Duan, S., Kozjek, D., Mehr, E., Anders, M., & Cao, J. (2024). Forming force prediction in double-sided incremental forming via GNN-based transfer learning. Journal of Manufacturing Processes, volume 120, pages 867-877.
import os
import time
import numpy as np
import pandas as pd
import torch
import torch_geometric.nn as geom_nn
import torch_geometric.data as geom_data
os.environ["KERAS_BACKEND"] = "torch"
import keras
from torch_geometric.data import InMemoryDataset
from tqdm import tqdm
from torch_geometric.loader import DataLoader
from torch_geometric.data import Data
from sklearn.metrics import r2_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
from torch.nn import BatchNorm1d,ReLU
from torch_geometric.nn import TopKPooling,SAGEConv,Linear,GCNConv,GATConv
from torch_geometric.nn import global_mean_pool as gap, global_max_pool as gmp
import torch.nn.functional as F
import matplotlib.pyplot as plt


df_s = pd.read_csv('data/sampled_s.csv')
df_m = pd.read_csv('data/sampled_m.csv')
df_l = pd.read_csv('data/sampled_l.csv')
df_p = pd.read_csv('data/sampled_p.csv')
df_f = pd.read_csv('data/sampled_f.csv')
test1 = pd.read_csv('data/sampled_1.csv')
test2 = pd.read_csv('data/sampled_2.csv')
test3 = pd.read_csv('data/sampled_3.csv')


for df in [df_s,df_m,df_l,df_p,df_f]:
  df['material'] = 0

for df in [test1,test2,test3]:
  df['material'] = 1

for data in [df_s,df_m,df_l,df_p,df_f,test1,test2,test3]:
  x1 = data['x'].values.reshape(-1, 1)
  y1 = data['y'].values.reshape(-1, 1)
  n_x = (x1.max()-x1.min())/2
  n_y = (y1.max()-y1.min())/2
  # Define the min-max scaler and fit_transform the x1 column
  scaler_x = MinMaxScaler(feature_range=(-n_x, n_x))
  scaler_y = MinMaxScaler(feature_range=(-n_y, n_y))
  x1_normalized = scaler_x.fit_transform(x1)
  y1_normalized = scaler_y.fit_transform(y1)

  # Replace the x1 column in the original dataframe with the normalized values
  data['x1'] = x1_normalized
  data['y1'] = y1_normalized

dataset = [df_s,df_m,df_l,df_p,df_f,test2,test3]
class YooChooseBinaryDataset_Train(InMemoryDataset):
    def __init__(self, root, transform=None, pre_transform=None):
        super(YooChooseBinaryDataset_Train, self).__init__(root, transform, pre_transform)
        self.data, self.slices = torch.load(self.processed_paths[0], weights_only=False)

    @property
    def raw_file_names(self):
        return []

    @property
    def processed_file_names(self):
        return ['yoochoose_click_binary_1M_sess.dataset']

    def download(self):
        pass

    def process(self):
        data_list = []
        global dataset
        for df in dataset:
             # Extract node features
            range_node = round(len(df))
            pos = df[['x', 'y']].iloc[:].values
            pos = [(row[0], row[1]) for row in pos]
            node_features = df[['x', 'y', 'z', 'nx','ny','nz','curv_x','curv_x','material']].iloc[:range_node].values
            node_features = torch.FloatTensor(node_features)
            # Convert the array to a PyTorch tensor
            pos = torch.FloatTensor(pos)
            x = node_features
            if (len(df) == len(test1))|(len(df) == len(test2))|(len(df) == len(test3)):
                y = torch.FloatTensor(df.rolling_mean.iloc[:range_node].values)
            else:
                y = torch.FloatTensor(df.fz1.iloc[:range_node].values)

            edge_index = []
            distances = torch.cdist(pos, pos)
            if len(df) == len(df_l):
              for i in range(range_node - 1):
                if distances[i, i+1]<=30:
                  edge_index.append([i, i+1])

            if len(df) == len(df_m):
              for i in range(range_node - 1):
                if distances[i, i+1]<=25:
                  edge_index.append([i, i+1])

            if len(df) == len(df_s):
              for i in range(range_node - 1):
                if (distances[i, i+1]<=17) | (i<=500):
                  if distances[i, i+1]<=25:
                    edge_index.append([i, i+1])

            if len(df) == len(df_p):
              for i in range(range_node - 1):
                # if distances[i, i+1]<=50:
                  edge_index.append([i, i+1])

            if len(df) == len(df_f):
              for i in range(range_node - 1):
                if distances[i, i+1]<=30:
                  edge_index.append([i, i+1])

            if len(df) == len(test2):
              for i in range(range_node - 1):
                # if distances[i, i+1]<=50:
                  edge_index.append([i, i+1])
            if len(df) == len(test3):
              for i in range(range_node - 1):
                # if distances[i, i+1]<=50:
                  edge_index.append([i, i+1])

            edge_num = 4
            top10_indices = torch.argsort(distances, dim=1)[:, 1:11]
            for i,row in enumerate(top10_indices):
              edge_count = 0
              for j in range(len(row)):
                if i < int(row[j]):
                  edge_index.append([i,int(row[j])])
                  edge_count += 1
                  if edge_count == edge_num:
                    break

            data = Data(x=x,y=y,pos=pos)
            edge_index = torch.tensor(edge_index, dtype=torch.long)
            data.edge_index=edge_index.t().contiguous()
            # Add edge attributes based on pairwise distances
            # edge_distances = distances[data.edge_index[0], data.edge_index[1]]
            # data.edge_attr = edge_distances.view(-1, 1)
            data_list.append(data)

        data, slices = self.collate(data_list)
        torch.save((data,slices), self.processed_paths[0])

class YooChooseBinaryDataset_Transfer(InMemoryDataset):
  def __init__(self,root,transform=None,pre_transform=None):
    super(YooChooseBinaryDataset_Transfer,self).__init__(root,transform,pre_transform)
    self.data, self.slices = torch.load(self.processed_paths[0], weights_only=False)

  @property
  def raw_file_names(self):
    return []

  @property
  def processed_file_names(self):
    return ['yoochoose_click_binary_1M_sess.dataset']

  def download(self):
     pass

  def process(self):
        data_list = []
        dataset = [test1]
        for df in dataset:
             # Extract node features
            range_nodes = round(0.3*len(df))
            pos = df[['x1', 'y1']].iloc[:range_nodes].values
            pos = [(row[0], row[1]) for row in pos]
            node_features = df[['x', 'y', 'z', 'nx','ny','nz','curv_x','curv_x','material']].iloc[:range_nodes].values
            node_features = torch.FloatTensor(node_features)
            # Convert the array to a PyTorch tensor
            pos = torch.FloatTensor(pos)
            x = node_features
            y = torch.FloatTensor(df.rolling_mean.iloc[:range_nodes].values)
            edge_index = []
            distances = torch.cdist(pos, pos)
            for i in range(range_nodes-1):
                edge_index.append([i, i+1])
            edge_num = 4
            top10_indices = torch.argsort(distances, dim=1)[:, 1:11]
            for i,row in enumerate(top10_indices):
              edge_count = 0
              for j in range(len(row)):
                if i < int(row[j]):
                  edge_index.append([i,int(row[j])])
                  edge_count += 1
                  if edge_count == edge_num:
                    break
            data = Data(x=x,y=y,pos=pos)
            edge_index = torch.tensor(edge_index, dtype=torch.long)
            data.edge_index=edge_index.t().contiguous()
            # Add edge attributes based on pairwise distances
            # edge_distances = distances[data.edge_index[0], data.edge_index[1]]
            # data.edge_attr = edge_distances.view(-1, 1)
            data_list.append(data)

        data, slices = self.collate(data_list)
        torch.save((data,slices), self.processed_paths[0])

class YooChooseBinaryDataset_TransValid(InMemoryDataset):
  def __init__(self,root,transform=None,pre_transform=None):
    super(YooChooseBinaryDataset_TransValid,self).__init__(root,transform,pre_transform)
    self.data, self.slices = torch.load(self.processed_paths[0], weights_only=False)

  @property
  def raw_file_names(self):
    return []

  @property
  def processed_file_names(self):
    return ['yoochoose_click_binary_1M_sess.dataset']

  def download(self):
     pass

  def process(self):
        data_list = []
        dataset = [test1]
        for df in dataset:
             # Extract node features
            ini_nodes = round(0.3*len(df))
            end_nodes = round(0.5*len(df))
            pos = df[['x1', 'y1']].iloc[ini_nodes:end_nodes].values
            pos = [(row[0], row[1]) for row in pos]
            node_features = df[['x', 'y', 'z', 'nx','ny','nz','curv_x','curv_x','material']].iloc[ini_nodes:end_nodes].values
            node_features = torch.FloatTensor(node_features)
            # Convert the array to a PyTorch tensor
            pos = torch.FloatTensor(pos)
            x = node_features
            y = torch.FloatTensor(df.rolling_mean.iloc[ini_nodes:end_nodes].values)
            edge_index = []
            distances = torch.cdist(pos, pos)
            for i in range(end_nodes-ini_nodes-1):
                edge_index.append([i, i+1])
            edge_num = 4
            top10_indices = torch.argsort(distances, dim=1)[:, 1:11]
            for i,row in enumerate(top10_indices):
              edge_count = 0
              for j in range(len(row)):
                if i < int(row[j]):
                  edge_index.append([i,int(row[j])])
                  edge_count += 1
                  if edge_count == edge_num:
                    break
            data = Data(x=x,y=y,pos=pos)
            edge_index = torch.tensor(edge_index, dtype=torch.long)
            data.edge_index=edge_index.t().contiguous()
            # Add edge attributes based on pairwise distances
            # edge_distances = distances[data.edge_index[0], data.edge_index[1]]
            # data.edge_attr = edge_distances.view(-1, 1)
            data_list.append(data)

        data, slices = self.collate(data_list)
        torch.save((data,slices), self.processed_paths[0])

class YooChooseBinaryDataset_Test(InMemoryDataset):
  def __init__(self,root,transform=None,pre_transform=None):
    super(YooChooseBinaryDataset_Test,self).__init__(root,transform,pre_transform)
    self.data, self.slices = torch.load(self.processed_paths[0], weights_only=False)

  @property
  def raw_file_names(self):
    return []

  @property
  def processed_file_names(self):
    return ['yoochoose_click_binary_1M_sess.dataset']

  def download(self):
     pass

  def process(self):
        data_list = []
        dataset = [test1]
        for df in dataset:
             # Extract node features
            range_nodes = round(0.5*len(df))
            pos = df[['x', 'y']].iloc[range_nodes:].values
            pos = [(row[0], row[1]) for row in pos]
            node_features = df[['x', 'y', 'z', 'nx','ny','nz','curv_x','curv_x','material']].iloc[range_nodes:].values
            node_features = torch.FloatTensor(node_features)
            # Convert the array to a PyTorch tensor
            pos = torch.FloatTensor(pos)
            x = node_features
            y = torch.FloatTensor(df.rolling_mean.iloc[range_nodes:].values)
            edge_index = []
            distances = torch.cdist(pos, pos)
            for i in range(len(df)-range_nodes-1):
                edge_index.append([i, i+1])

            edge_num = 4
            top10_indices = torch.argsort(distances, dim=1)[:, 1:11]
            for i,row in enumerate(top10_indices):
              edge_count = 0
              for j in range(len(row)):
                if i < int(row[j]):
                  edge_index.append([i,int(row[j])])
                  edge_count += 1
                  if edge_count == edge_num:
                    break
            data = Data(x=x,y=y,pos=pos)
            edge_index = torch.tensor(edge_index, dtype=torch.long)
            data.edge_index=edge_index.t().contiguous()
            # Add edge attributes based on pairwise distances
            # edge_distances = distances[data.edge_index[0], data.edge_index[1]]
            # data.edge_attr = edge_distances.view(-1, 1)
            data_list.append(data)

        data, slices = self.collate(data_list)
        torch.save((data,slices), self.processed_paths[0])

num_dataset = 1
train_pre = YooChooseBinaryDataset_Train(root=f'data_train{num_dataset}/')
transfer_dataset = YooChooseBinaryDataset_Transfer(root=f'data_transfer{num_dataset}/')
transvalid_dataset = YooChooseBinaryDataset_TransValid(root=f'data_TransValid{num_dataset}/')
test_dataset = YooChooseBinaryDataset_Test(root=f'data_Test{num_dataset}/')

hidden_dim = 16

class GATNet(torch.nn.Module):
  def __init__(self):

###### Frame : GAT ######

    super().__init__()
    self.conv1 = GATConv(train_pre.num_node_features, hidden_dim)
    self.conv2 = GATConv(hidden_dim, hidden_dim)
    self.predict1 = Linear(hidden_dim, 16)
    self.predict2 = Linear(16, 8)
    self.predict3 = Linear(8, 1)

  def forward(self,data):

    x, edge_index, batch_index = data.x.to(torch.float32), data.edge_index, data.batch
    hidden = self.conv1(x, edge_index)
    hidden = torch.tanh(hidden)
    hidden = self.conv2(hidden, edge_index)
    hidden = torch.tanh(hidden)
    hidden = self.predict1(hidden)
    hidden = self.predict2(hidden)
    out = self.predict3(hidden)
    return out


def remap_edge_index(edge_index, num_nodes):
    # Create a mask of valid node indices
    mask = (edge_index < num_nodes).all(dim=0)

    # Filter the edge index to only include edges between valid nodes
    remapped_edge_index = edge_index[:, mask]

    return remapped_edge_index

# Function to split nodes for each graph
def create_mask(data, val_percent=0.2):
    num_nodes = data.num_nodes
    # Create a mask for the entire dataset
    mask = torch.rand(num_nodes) > val_percent
    train_mask = mask
    val_mask = ~mask
    return train_mask, val_mask

# Training and validation function
def train_and_validate(train_loader, crit, optimizer, reg_lambda):
    train_loss_all = 0
    val_loss_all = 0

    # Training
    model4.train()
    for data in train_loader:
        # Assuming 'data' is your graph data object with 'x' being the node features and 'edge_index' being the edge list
        data.edge_index = remap_edge_index(data.edge_index, data.x.size(0))
        train_mask, val_mask = create_mask(data)
        optimizer.zero_grad()

        output = model4(data).squeeze(1)
        label = data.y

        # Apply the mask for the training nodes
        output_train = output[train_mask]
        label_train = label[train_mask]

        # Calculate loss and perform backpropagation
        loss = crit(output_train, label_train)
        loss += reg_lambda * sum(param.norm(2) for param in model4.parameters())
        loss.backward()

        optimizer.step()
        train_loss_all += loss.item()

    # Validation
    model4.eval()
    with torch.no_grad():
        for data in train_loader:
            # Assuming 'data' is your graph data object with 'x' being the node features and 'edge_index' being the edge list
            data.edge_index = remap_edge_index(data.edge_index, data.x.size(0))
            train_mask, val_mask = create_mask(data)

            output = model4(data).squeeze(1)
            label = data.y

            # Apply the mask for the validation nodes
            output_val = output[val_mask]
            label_val = label[val_mask]

            # Calculate validation loss
            val_loss = crit(output_val, label_val)
            val_loss_all += val_loss.item()

    # Calculate average losses
    avg_train_loss = train_loss_all / len(train_loader.dataset)
    avg_val_loss = val_loss_all / len(train_loader.dataset)  # Assuming validation is done on the same graphs

    return avg_train_loss, avg_val_loss


model4 = GATNet()
model4.eval()
reg_lambda = 0.01
optimizer = torch.optim.Adam(model4.parameters(), lr=0.001, weight_decay=reg_lambda)
crit = torch.nn.MSELoss()
train_loader = DataLoader(train_pre, batch_size=1, shuffle=True)
data_size = len(train_pre)

train_losses = []
val_losses = []

# Run training and validation
num_epochs = 5000
start_time = time.time()
for epoch in tqdm(range(num_epochs)):
    # Train
    train_loss, val_loss = train_and_validate(train_loader, crit, optimizer, reg_lambda)
    train_losses.append(train_loss)
    val_losses.append(val_loss)
    if epoch%50 == 0:
        print(f"Epoch {epoch} | Training loss {train_loss:.4f} | Validation loss {val_loss:.4f}")
        test_loader = DataLoader(test_dataset, batch_size=1, shuffle=False)
        predictions,grounds = [],[]
        for batch in test_loader:
          prediction = model4(batch).squeeze(1).tolist()
          predictions += prediction
          
          ground_truth = batch.y.squeeze(0).tolist()
          grounds += ground_truth

        print(f'          r2 score = ',r2_score(grounds, predictions))
        difference,mean = [],[]
        for i in range(len(predictions)):
          difference.append(np.abs(predictions[i]-grounds[i]))
        print('difference_max: ',np.max(difference))
        print('difference_mean: ',np.mean(difference))
        print('difference_min: ',np.min(difference))
        print('=========================================================')
        end_time = time.time()
        running_time_ms = (end_time - start_time) * 1000

        print(f"The process took {running_time_ms:.2f} ms to run.")


ini_time = time.time()
prediction = model4(batch).squeeze(1).tolist()
end_time = time.time()
running_time_ms = (end_time - ini_time) * 1000

print(f"The process took {running_time_ms:.2f} ms to run.")

larger_set = []
for i in range(1000):
  larger_set.append(test_dataset[0])

ini_time = time.time()
for batch in larger_set:
  prediction = model4(batch).squeeze(1).tolist()
end_time = time.time()
running_time_ms = (end_time - ini_time) * 1000

print(f"The process took {running_time_ms:.2f} ms to run.")

largerer_set = []
scale_num = 100000
for i in range(scale_num):
  largerer_set.append(test_dataset[0])
test_loader = DataLoader(largerer_set, batch_size=128, shuffle=False)


ini_time = time.time()
for batch in tqdm(test_loader, desc="Processing batches"):
  prediction = model4(batch).squeeze(1).tolist()
end_time = time.time()
running_time_ms = (end_time - ini_time) * 1000
print(f"The process took {running_time_ms:.2f} ms to run.")

test_loader = DataLoader(test_dataset, batch_size=1, shuffle=False)
pre_predictions = []
pre_grounds = []
for batch in test_loader:
  pre_prediction = model4(batch).squeeze(1).tolist()
  pre_predictions += pre_prediction
  pre_label = batch.y.squeeze(0).tolist()
  pre_grounds += pre_label


colors = ["black", "violet", "deeppink", "navy", "grey", "teal", "blue", "dodgerblue", "darkgrey", "red", "blueviolet"]
plt.figure(figsize=(8,6))


plt.rcParams['figure.dpi'] = 200
plt.rcParams.update({'font.size': 22})
plt.plot(train_losses,color=colors[6])
plt.plot(val_losses,color=colors[9])

plt.legend(['Training', 'Validation'])

df = test1

def custom_rolling_mean(arr):
    # Use only non-NaN values to calculate the mean
    arr = arr[~np.isnan(arr)]
    return np.mean(arr)
true_values = df.rolling_mean.values.tolist()
rolling_num = 30
pre_pred_mean = pd.Series(pre_predictions).rolling(window=rolling_num, center=True, min_periods=1).apply(custom_rolling_mean)
pre_whole_true_mean = pd.Series(true_values).rolling(window=1, center=True, min_periods=1).apply(custom_rolling_mean)
pre_true_mean = pd.Series(pre_grounds).rolling(window=1, center=True, min_periods=1).apply(custom_rolling_mean)

plt.figure(figsize=(12, 6))
plt.rcParams['figure.dpi'] = 200
plt.rcParams.update({'font.size': 22})
plt.yticks(range(2200, 3000, 100))


indices = [i for i, l in enumerate(pre_pred_mean)]
for i in range(len(indices)):
    indices[i] += round(len(pre_pred_mean))
plt.plot(indices[:],pre_true_mean[:], label='Ground Truth',c=colors[9])
plt.plot(indices[:],pre_pred_mean[:], label='Predicted Value',c=colors[6])


legend = plt.legend(loc='upper right')
ax = plt.gca().add_artist(legend)

plt.text(0.02, 0.05,  "Rolling average calculated by every 30 data points", transform=plt.gca().transAxes,
         color='black', ha='left', va='bottom')

plt.show()

print(f"Test set: r2 score = {r2_score(pre_true_mean, pre_pred_mean)}")

plt.figure(figsize=(12, 6))
plt.rcParams['figure.dpi'] = 200
plt.rcParams.update({'font.size': 22})
plt.yticks(range(1000, 3500, 500))

indices = [i for i, l in enumerate(pre_pred_mean)]
for i in range(len(indices)):
    indices[i] += round(len(pre_pred_mean))
plt.plot(pre_whole_true_mean[:], label='Ground Truth',c=colors[9])
plt.plot(indices[:],pre_pred_mean[:], label='Predicted Value',c=colors[6])


legend = plt.legend(loc='center right')
ax = plt.gca().add_artist(legend)

plt.text(0.15, 0.05,  "Rolling average calculated by every 30 data points", transform=plt.gca().transAxes,
          color='black', ha='left', va='bottom')

plt.show()

pre_difference,pre_mean = [],[]
for i in range(len(pre_pred_mean[:])):
  pre_difference.append(np.abs(pre_pred_mean[i]-pre_true_mean[i]))
for i in range(len(pre_pred_mean[:])):
  pre_mean.append(np.mean(pre_difference))

plt.figure(figsize=(12, 6))
plt.rcParams['figure.dpi'] = 200
plt.rcParams.update({'font.size': 22})
plt.plot(indices[:], pre_difference, label='difference value',c=colors[6])
plt.plot(indices[:], pre_mean, label='difference mean',c=colors[9])
plt.show()

print('difference_max: ',np.max(pre_difference))
print('difference_mean: ',np.mean(pre_difference))
print('difference_min: ',np.min(pre_difference))

# # Save the trained model parameters
torch.save(model4.state_dict(), 'pretrain_test1.pth')

# Create a new model with the same architecture as the trained model
transfer_model = GATNet()

# Load the trained model parameters into the new model
transfer_model.load_state_dict(torch.load('pretrain_test1.pth'))

# Freeze some layers of the transfer model (e.g. the first two layers)
for param in transfer_model.conv1.parameters():
    param.requires_grad = False
for param in transfer_model.conv2.parameters():
    param.requires_grad = False
for param in transfer_model.predict1.parameters():
    param.requires_grad = False

# Add two new layers to the transfer model
# transfer_model.fc1 = Linear(1, 32)
# transfer_model.fc2 = Linear(32, 1)

# Create a new optimizer that only updates the unfrozen layers of the transfer model
transfer_loader = DataLoader(transfer_dataset, batch_size=1, shuffle=False)
transvalid_loader = DataLoader(transvalid_dataset, batch_size=1, shuffle=False)
test_loader = DataLoader(test_loader, batch_size=1, shuffle=False)

# Train the unfrozen layers of the transfer model on the new data
transfer_optimizer = torch.optim.Adam(transfer_model.parameters(), lr=0.0001, weight_decay=reg_lambda)
def transfer():
  transfer_model.train()
  loss_all=0
  loss_list=[]
  for data in transfer_loader:
    data=data
    transfer_optimizer.zero_grad()
    output = transfer_model(data).squeeze(1)
    lable=data.y
    loss=crit(output,lable)
    # loss += reg_lambda * sum(param.norm(2) for param in transfer_model.parameters())  # L2 regularization
    loss.backward()
    loss_all += data.num_graphs * loss.item()
    transfer_optimizer.step()
  transfer_model.eval()
  val_loss_all = 0
  with torch.no_grad():
      for val_data in transvalid_loader:
          val_output = transfer_model(val_data).squeeze(1)
          val_label = val_data.y
          val_loss = crit(val_output, val_label)
          val_loss_all += val_data.num_graphs * val_loss.item()
  val_loss = val_loss_all / len(transvalid_dataset)
  return loss_all / len(transfer_dataset), val_loss

start_time = time.time()
transfer_losses,transvalid_losses = [],[]
for epoch in range(48):
    # Train
    transfer_loss,transvalid_loss = transfer()
    transfer_losses.append(transfer_loss)
    transvalid_losses.append(transvalid_loss)
    if epoch%1 == 0:
        print(f"Epoch {epoch} | Training loss {transfer_loss:.4f} | Validation loss {transvalid_loss:.4f}")
        test_loader = DataLoader(test_dataset, batch_size=1, shuffle=False)
        predictions_transfer,grounds_transfer = [],[]
        for batch in test_loader:
          prediction = transfer_model(batch).squeeze(1).tolist()
          predictions_transfer += prediction
          # print(f'pred_y = {type(prediction)}')
          ground_truth = batch.y.squeeze(0).tolist()
          grounds_transfer += ground_truth

        print(f'          r2 score = ',r2_score(grounds_transfer, predictions_transfer))
        difference_transfer,mean_transfer = [],[]
        for i in range(len(predictions_transfer)):
          difference_transfer.append(np.abs(predictions_transfer[i]-grounds_transfer[i]))
        print('difference_max: ',np.max(difference_transfer))
        print('difference_mean: ',np.mean(difference_transfer))
        print('difference_min: ',np.min(difference_transfer))
        print('=========================================================')
end_time = time.time()
running_time_ms = (end_time - start_time) * 1000

print(f"The process took {running_time_ms:.2f} ms to run.")

test_loader = DataLoader(test_dataset, batch_size=1, shuffle=False)
transfer_predictions = []
transfer_grounds = []
for batch in test_loader:
  transfer_prediction = transfer_model(batch).squeeze(1).tolist()
  transfer_predictions += transfer_prediction
  transfer_label = batch.y.squeeze(0).tolist()
  transfer_grounds += transfer_label

plt.figure(figsize=(8,6))
plt.rcParams['figure.dpi'] = 200
plt.rcParams.update({'font.size': 22})
plt.plot(transfer_losses,color=colors[6])
plt.plot(transvalid_losses,color=colors[9])
plt.legend(['Training', 'Validation'],fontsize=20)

def custom_rolling_mean(arr):
    # Use only non-NaN values to calculate the mean
    arr = arr[~np.isnan(arr)]
    return np.mean(arr)

rolling_num = 30
transfer_pred_mean = pd.Series(transfer_predictions).rolling(window=rolling_num, center=True, min_periods=1).apply(custom_rolling_mean)
transfer_true_mean = pd.Series(transfer_grounds).rolling(window=1, center=True, min_periods=1).apply(custom_rolling_mean)

plt.figure(figsize=(12, 6))

plt.rcParams['figure.dpi'] = 200
plt.rcParams.update({'font.size': 22})
plt.yticks(range(2200, 3000, 100))

indices = [i for i, l in enumerate(transfer_pred_mean)]
for i in range(len(indices)):
    indices[i] += round(len(transfer_pred_mean))
plt.plot(indices[:],transfer_true_mean[:], label='Ground Truth', c=colors[9])
plt.plot(indices[:],transfer_pred_mean[:], label='Predicted Value', c=colors[6])


legend = plt.legend(loc='upper right')
ax = plt.gca().add_artist(legend)

plt.text(0.02, 0.05,  "Rolling average calculated by every 30 data points", transform=plt.gca().transAxes,
          color='black', ha='left', va='bottom')

plt.show()

print(f"Test set: r2 score = {r2_score(transfer_true_mean, transfer_pred_mean)}")

plt.figure(figsize=(12, 6))
plt.rcParams['figure.dpi'] = 200
plt.rcParams.update({'font.size': 22})
plt.yticks(range(1000, 3500, 500))

indices = [i for i, l in enumerate(transfer_pred_mean)]
for i in range(len(indices)):
    indices[i] += round(len(transfer_pred_mean))


plt.plot(pre_whole_true_mean[:], label='Ground Truth', c=colors[9])
plt.plot(indices[:],transfer_pred_mean[:], label='Predicted Value',c=colors[6])
legend = plt.legend(loc='center right')
ax = plt.gca().add_artist(legend)

plt.text(0.15, 0.05,  "Rolling average calculated by every 30 data points", transform=plt.gca().transAxes,
         color='black', ha='left', va='bottom')

plt.show()

transfer_difference,transfer_mean = [],[]
for i in range(len(transfer_pred_mean)):
  transfer_difference.append(np.abs(transfer_pred_mean[i]-transfer_true_mean[i]))
for i in range(len(transfer_pred_mean)):
  transfer_mean.append(np.mean(transfer_difference))

plt.figure(figsize=(12, 6))
plt.rcParams['figure.dpi'] = 200
plt.rcParams.update({'font.size': 22})
plt.plot(indices[:], transfer_difference, label='difference value',c=colors[6])
plt.plot(indices[:], transfer_mean, label='difference mean',c=colors[9])
plt.show()

print('difference_max: ',np.max(transfer_difference))
print('difference_mean: ',np.mean(transfer_difference))
print('difference_min: ',np.min(transfer_difference))
